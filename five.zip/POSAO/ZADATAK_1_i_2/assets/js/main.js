$(document).ready(function () {

    //Validation form for registration user
    $("#registration").click(function(){
        
        var firstName = $('#first_name');
        var lastName = $('#last_name');
        var email = $('#email');
        var city = $('#city');
        var address = $('#address');
        var gender = $('input[name="gender"]:checked').val();
        var dateBirth = $('#dateBirth');
        var note = $('#note');
        var chEmail = $('#chEmailSend').is(':checked');


        var dataUser = new Array();

        var regexName = /^[A-ZŠĐŽČĆ][a-zšđžčć]{2,17}(\s[A-ZŠĐŽČĆ][a-zšđžčć]{2,20})*$/;
        var regexEmail = /^[a-z]([\.-]?\w+\d*)*@\w+\.\w{2,6}$/;
        var regexAddress = /^[A-Za-z0-9'\.\-\s\,\/]{3,}/;

        //FirstName
        if(firstName.val() == '')
        {
        $(".error_mess").text("First name is a required field"); 
        }   
        else if (!regexName.test(firstName.val()))
        {
            $(".error_mess").text("e.g. John"); 
        }
        else
        {
            $(".error_mess").text(""); 
            dataUser.push(firstName.val());
        }

        //LastName
        if(lastName.val() == '')
        {
        $(".error_messl").text("Last name is a required field"); 
        }   
        else if (!regexName.test(lastName.val()))
        {
            $(".error_messl").text("e.g. Hansen"); 
        }
        else
        {
            $(".error_messl").text(""); 
            dataUser.push(lastName.val());
        }

        //Email
        if(email.val() == '')
        {
            $(".error_messE").text("Email is a required field"); 
        }   
        else if (!regexEmail.test(email.val()))
        {
            $(".error_messE").text("Email must be in good format e.g. johnhansen@gmail.com"); 
        }
        else
        {
            $(".error_messE").text(""); 
            dataUser.push(email.val());
        }

        //City
        if(city.val() == '0')
        {
            $(".error_messC").text("City must be selected"); 
        }
        else
        {
            $(".error_messC").text(""); 
            dataUser.push(city.val());//we can insert in array text from options tag but value is better 
        }

         //Address
         if(address.val() == '')
         {
             $(".error_messA").text("Address is a required field"); 
         }   
         else if (!regexAddress.test(address.val()))
         {
             $(".error_messA").text("Address must be in good format e.g. Zmaj Jovina 23/1"); 
         }
         else
         {
             $(".error_messA").text(""); 
             dataUser.push(address.val());
         }

        //Date
        if(dateBirth.val() == '')
        {
            $(".error_messD").text("Date is required field"); 
        }
        else if(!isInThePast(new Date(dateBirth.val()))){
            $(".error_messD").text("Date mast be in the past"); 
        }
        else
        {
            $(".error_messD").text(""); 
            dataUser.push(dateBirth.val());
        }
        
        //Note
        if(note.val() == '')
        {
            $(".error_messN").text("Note is required field"); 
        }
        else
        {
            $(".error_messN").text(""); 
            dataUser.push(note.val());
        }
        dataUser.push(gender, chEmail);

        if(dataUser.length == 9){
            $.ajax({
                url:'registration.php',//send data od this file and insert in database
                method: "post",
                data: {
                    data:dataUser
                },
                dataType: "json",
                success: function(result){
                    // any code for print success message
                },
                error: function(xhr){
                    // catch status code end generate message
                    // if(xhr.status == 422){
                    //     $("#odgovor").html(`<p class="alert alert-warning">Doslo je do greske prilikom obrade podataka.</p>`)
                    // }
                    // if(xhr.status == 500){
                        
                    // }
                }
            })

            $('.registration_form').html('<div class="alert alert-success text-center" role="alert">Success registration!</div>');

            var nameFilds = ['First name', 'Last name','Email','City', 'Address','Date of birth', 'Note','Gender','Send me email'];
            var dataList = "<ul class='alert alert-success'>";
            for (const [index, value] of dataUser.entries()) {
                dataList += `<li>${nameFilds[index]}: ${value}</li>`
            }
            dataList += "</ul>"
            $('.dataOfUser').html(dataList);
        }

        
    
        
    })

    function isInThePast(date) {
        const today = new Date();

        today.setHours(0, 0, 0, 0);
      
        return date < today;
      }


})