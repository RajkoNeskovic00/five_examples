<?php
    include "pages/head.php";
    include "pages/nav.php";
?>

       
    <div class="container">
        <div class="row">
            <div class="col-6 mx-auto py-5">
                <p>Hello, if you scan folder in this project, click on orange button and start action!</p>
                
            </div>
        </div>
    </div>


<?php
    include "pages/footer.php";
?>