$(document).ready(function(){
    $('#btnScan').click(function(){
        
        let namFolder = $('#name');

        var errors = 0;
        var folders = ['folder','folders'];


        if($(namFolder).val() == ''){
            errors++;
            $(namFolder).addClass('error');
        }
        else if(!folders.includes($(namFolder).val())){
            $(".err_mes").text('Folder not found');
        }
        else{
            $(namFolder).removeClass('error');
            $(".err_mes").text('');
        }


        if(errors == 0){
            let data = {
                "nameFolder": "C:/xampp/htdocs/ZADATAK_4/"+ $(namFolder).val(),
                "btnKlik": true
            };
    
            //PODACI SE SALJU U PHPNA OBRADU
            $.ajax({
                url: "models/scan-folder.php",
                method: "POST",
                dataType: "json",
                data: data,
                success:function(data){
                    printScannedFolder(data);
                },
                error:function(xhr){
                    console.log(xhr);
                }
            })

           
    
        }
    })

    $(document).on('click','.sub_folder',function(){
        var subName = $(this).data('dir');
        
        var dataSub = {
            "nameFolder": subName,
            "btnKlik": true
        };

        //PODACI SE SALJU U PHPNA OBRADU
        $.ajax({
            url: "models/scan-folder.php",
            method: "POST",
            dataType: "json",
            data: dataSub,
            success:function(data){
                printScannedFolder(data);
            },
            error:function(xhr){
                console.log(xhr);
            }
        })
        
    })

    function printScannedFolder(datas){
        print = "";
        for (const el of datas) {
            print += el;
        }

        $('.message_response').html(print);
    }

    

 })