<?php
        $arrayResponse = array();        
        function scanning_folder($path, $sub = null, $entry_last = null){
            global $arrayResponse;  
            if($fh = opendir($path)){
                while(($entry = readdir($fh)) != false){
                    if($entry != '.' && $entry != '..' ){
                        if($sub != null){
                            array_push($arrayResponse,"<a >/".$entry_last."/".$entry."</a><br>");
                        }else{
                            if(is_file($path . DIRECTORY_SEPARATOR . $entry)){
                                array_push($arrayResponse,"<a  target='_blank'  href = ".$path . "/" . $entry." >/".$entry."</a><br>");
                            }
                            else if(is_dir($path . DIRECTORY_SEPARATOR . $entry)){
                                array_push($arrayResponse,"<a class='sub_folder'  data-dir = ".$path."/".$entry." >/".$entry."</a><br>");
                            }
                        }
                        
                        //path to folder  href = ".$entry."
                        $thisEntry = $path . DIRECTORY_SEPARATOR . $entry;
                        
                        if(is_dir($thisEntry)){   
                            scanning_folder($thisEntry,"sub",$entry);
                        }
                    }
                }
                return $arrayResponse;
            }
        }
?>