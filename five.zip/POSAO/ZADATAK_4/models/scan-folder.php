<?php
    header("Content-type: application/json");
    if(isset($_POST["btnKlik"])){
        include "functions.php";
        $folderName = $_POST['nameFolder'];
        
        if($folderName == ""){
            echo json_encode();
            http_response_code(422);
        }else{
            $path = $folderName;
     
            $files = scanning_folder($path);
               
            echo json_encode($files);
            http_response_code(200);
                
        }        
    }
    else{
        echo json_encode();
        http_response_code(404);
    }
?>