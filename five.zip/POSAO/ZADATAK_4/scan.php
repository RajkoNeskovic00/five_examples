<?php
    include "pages/head.php";
    include "pages/nav.php";
?>

       
    <div class="container">
        <div class="row">
            <div class="col-6 mx-auto py-5">
                <form class = "mt-4">
                    <div class="form-group">
                        <label for="">Select folder name</label>
                        <select id="name" class="custom-select">
                            <option value="folder">folder</option>
                            <option value="folders">folders</option>

                        </select>
                        <span class = "err_mes text-danger"><span>
                    </div>
                    <input type="button" value="Scan now!"  id="btnScan" class="btn btn-primary">
                    
                </form>

                <div class="message_response mt-3" ></div>
            </div>
        </div>
    </div>


<?php
    include "pages/footer.php";
?>