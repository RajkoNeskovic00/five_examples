$(document).ready(function () {
    var dogs_array_image = ['husky.jpg','huskyOld.jpg','huskyInSnow.jpg'];
    var dogs_array_alt = ['husky','husky_old','husky_snow'];

    var printSlider = '';

    for (let [index, value] of dogs_array_image.entries()) {
        printSlider += `<div><img src="assets/images/${value}" alt="${dogs_array_alt[index]}"></div>`;
    }

    $('.slider_bar').html(printSlider);

    $('.slider_bar').slick({
        dots: true,
        infinite: true,
        speed: 800,
        slidesToShow: 1,
        adaptiveHeight: true
    });

})